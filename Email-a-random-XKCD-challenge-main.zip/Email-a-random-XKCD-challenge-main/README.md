﻿Email a random XKCD challenge

A PHP application accepts a visitor’s email address and emails them random XKCD comics 


Email a random XKCD challenge


Demo link: http://xkcd.ictmu.in/



*index.php is used for the sending **email** with **unique hash** to entered email address.*

*verify.php is used to **verify email based on the sent hash**.*

*unsubscribe.php is used to **unsubscribe the facility of getting XKCD comics**.*

 email is sent every **cron job** of XKCD_mail.php which is used to send XKCD  from API.*







